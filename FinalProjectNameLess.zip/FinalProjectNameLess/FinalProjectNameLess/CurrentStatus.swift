//
//  CurrentStatus.swift
//  FinalProjectNameLess
//
//  Created by Thadisetti, Hari Kishore on 12/7/19.
//  Copyright © 2019 NameLess. All rights reserved.
//

import Foundation

class CurrentStatus
{
    
}
